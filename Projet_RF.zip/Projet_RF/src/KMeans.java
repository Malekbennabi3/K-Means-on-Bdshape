import java.util.ArrayList;
import java.util.Random;


public class KMeans {

    //Tableau de Formes BDShape
    public Forme[][] t_dataPoints;
    // Number of clusters
    public int k;
    //Liste de Formes (Centre de chaque Cluster) 9 selon le nombre de classes
    public ArrayList<Forme> centroids;

    //Constructeur de la Classe KMeans
    public KMeans(Forme[][] t_dataPoints, int k) {
        this.t_dataPoints = t_dataPoints;
        this.k = k;
        centroids = initialiser_Centroids();
        //initializeCentroids();
    }

    // 2- Initialiser des centroids au hasard
    public ArrayList<Forme> initialiser_Centroids() {
        Random rand = new Random();
        ArrayList<Forme> centroids = new ArrayList<>();

        //Selectionner une forme au hasard pour chaque Classe
        for (int i = 0; i < k; i++) {
            // un entier au hasard de 0 - 11 (qui correspondra au nombre de l'echantillon)
            int randomIndex = rand.nextInt(11);    //(t_dataPoints1[0].length);
            //Ajouter la forme choisit au hasard a la liste initiales des centroids
            centroids.add(t_dataPoints[i][randomIndex]);
        }
        //Liste des Centres de classes choisies
        //this.centroids=centroids;
        return centroids;
    }


    // 3- Assigner chaque Forme au centre le plus proche
    public void assigner_Clusters(String s, int p) {
        switch (s) {
            case "E34":
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 11; j++) {

                        //On assigne la valeur  +(Infini) a la variable Distance minimale
                        double minDistance = Double.MAX_VALUE;
                        double distance;
                        int clusterIndex = -1;
                        //for (int t = 0; t < k; t++) {
                        for (int t = 0; t < k; t++) {

                            // (À Appliquer sur tous les caracteristiques (Listes E34, GFD, SA, F0) )
                            //Calculer la distance entre le point actuel et tous les centres

                            // puis assigner le point actuel aux centre le plus proche(Avec la petite distance)
                            distance = calculateDistance(t_dataPoints[i][j].E34, centroids.get(t).getE34(), p);
                            if (distance < minDistance) {
                                minDistance = distance;
                                clusterIndex = t;
                            }
                        }
                        // Assigner la Forme au plus proche centre
                        t_dataPoints[i][j].setCluster(clusterIndex);
                    }
                }
                break;
            case "GFD":
                for (int i = 0; i < 9; i++){
                    for (int j = 0; j < 11; j++){

                        //On assigne la valeur  +(Infini) a la variable Distance minimale
                        double minDistance = Double.MAX_VALUE;
                        double distance;
                        int clusterIndex = -1;
                        //for (int t = 0; t < k; t++) {
                        for (int t = 0; t < k; t++) {

                            // (À Appliquer sur tous les caracteristiques (Listes E34, GFD, SA, F0) )
                            //Calculer la distance entre le point actuel et tous les centres

                            // puis assigner le point actuel aux centre le plus proche(Avec la petite distance)
                            distance = calculateDistance(t_dataPoints[i][j].GFD, centroids.get(t).getGFD(), p);
                            if (distance < minDistance) {
                                minDistance = distance;
                                clusterIndex = t;
                            }
                        }
                        // Assigner la Forme au plus proche centre
                        t_dataPoints[i][j].setCluster(clusterIndex);
                    }
                }
                break;
            case "SA":
                for (int i = 0; i < 9; i++){
                    for (int j = 0; j < 11; j++){

                        //On assigne la valeur  +(Infini) a la variable Distance minimale
                        double minDistance = Double.MAX_VALUE;
                        double distance;
                        int clusterIndex = -1;
                        //for (int t = 0; t < k; t++) {
                        for (int t = 0; t < k; t++) {

                            // (À Appliquer sur tous les caracteristiques (Listes E34, GFD, SA, F0) )
                            //Calculer la distance entre le point actuel et tous les centres

                            // puis assigner le point actuel aux centre le plus proche(Avec la petite distance)
                            distance = calculateDistance(t_dataPoints[i][j].SA, centroids.get(t).getSA(), p);
                            if (distance < minDistance) {
                                minDistance = distance;
                                clusterIndex = t;
                            }
                        }
                        // Assigner la Forme au plus proche centre
                        t_dataPoints[i][j].setCluster(clusterIndex);
                    }
                }
                break;
            case "F0":
                for (int i = 0; i < 9; i++){
                    for (int j = 0; j < 11; j++){

                        //On assigne la valeur  +(Infini) a la variable Distance minimale
                        double minDistance = Double.MAX_VALUE;
                        double distance;
                        int clusterIndex = -1;
                        //for (int t = 0; t < k; t++) {
                        for (int t = 0; t < k; t++) {

                            // (À Appliquer sur tous les caracteristiques (Listes E34, GFD, SA, F0) )
                            //Calculer la distance entre le point actuel et tous les centres

                            // puis assigner le point actuel aux centre le plus proche(Avec la petite distance)
                            distance = calculateDistance(t_dataPoints[i][j].F0, centroids.get(t).getF0(), p);
                            if (distance < minDistance) {
                                minDistance = distance;
                                clusterIndex = t;
                            }
                        }
                        // Assigner la Forme au plus proche centre
                        t_dataPoints[i][j].setCluster(clusterIndex);
                    }
                }
                break;
        }
    }

    //4- Calculer le nouveau Centroid en se basant sur la moyenne de chaque Cluster
    private void ajuster_Centroids(String s) {

        //Liste contenant les nouveaux centres
        ArrayList<Forme> newCentroids = new ArrayList<>();

        switch (s) {
            case "E34":
                //Listes pour calculer la moyenne de chaque caracteristique
                ArrayList<Double> totalE34 = new ArrayList<>();

                //initialiser la Liste avec des zeros
                for (int i = 0; i < t_dataPoints[0][0].E34.size(); i++) {
                    totalE34.add(0.0);
                }

                //Parcourir tous les elements des centroids
                for (int z = 0; z < k; z++) {

                    //Parcourir tous les elements de la caracteristique E34 (16 elements)
                    int count = 0;
                    //Parcourir tout le tableau de Formes
                    for (int i = 0; i < t_dataPoints.length; i++) {
                        for (int j = 0; j < t_dataPoints[0].length; j++) {

                            //Si la forme actuelle est dans le même cluster que le centroid actuel
                            if (t_dataPoints[i][j].getCluster() == z) {
                                //TotalE34[j] +=Forme[i][j].E34[j]
                                for (int it = 0; it < totalE34.size(); it++) {
                                    totalE34.set(it, totalE34.get(it) + t_dataPoints[i][j].E34.get(it));
                                    count++;
                                }
                            }
                        }
                    }
                    if (count > 0) {
                        for (int i = 0; i < totalE34.size(); i++) {
                            //Assigner la moyenne des valeurs dans la meme position ( Somme(total[i])/ nombre_total)
                            totalE34.set(i, totalE34.get(i) / count);
                        }
                        newCentroids.add(new Forme(totalE34, null, null, null));
                    }
                }
                //Le centroid reçois les nouveaux centres
                this.centroids = newCentroids;
                totalE34.clear();
                break;
            case "GFD":
                //Listes pour calculer la moyenne de chaque caracteristique
                ArrayList<Double>  totalGFD= new ArrayList<>();

                //initialiser la Liste avec des zeros
                for(int i = 0; i< t_dataPoints[0][0].GFD.size(); i++){ totalGFD.add(0.0);}

                //Parcourir tous les elements des centroids
                for (int z = 0; z < k; z++) {

                    //Parcourir tous les elements de la caracteristique E34 (16 elements)
                    int count = 0;
                    //Parcourir tout le tableau de Formes
                    for (int i = 0; i < t_dataPoints.length; i++) {
                        for(int j = 0; j < t_dataPoints[0].length; j++) {

                            //Si la forme actuelle est dans le même cluster que le centroid actuel
                            if (t_dataPoints[i][j].getCluster() == z) {
                                //TotalE34[j] +=Forme[i][j].E34[j]
                                for(int it=0; it< totalGFD.size(); it++){
                                    totalGFD.set(it, totalGFD.get(it) + t_dataPoints[i][j].GFD.get(it));
                                    count++; }}
                        } }
                    if(count>0){
                        for(int i=0;i<totalGFD.size();i++) {
                            //Assigner la moyenne des valeurs dans la meme position ( Somme(total[i])/ nombre_total)
                            totalGFD.set(i, totalGFD.get(i)/count);}
                        newCentroids.add(new Forme(null, totalGFD,null,null)); }
                }
                //Le centroid reçois les nouveaux centres
                this.centroids = newCentroids;
                totalGFD.clear();
                break;

            case "SA":
                //Listes pour calculer la moyenne de chaque caracteristique
                ArrayList<Double>  totalSA = new ArrayList<>();

                //initialiser la Liste avec des zeros
                for(int i = 0; i< t_dataPoints[0][0].SA.size(); i++){ totalSA.add(0.0);}

                //Parcourir tous les elements des centroids
                for (int z = 0; z < k; z++) {

                    //Parcourir tous les elements de la caracteristique E34 (16 elements)
                    int count = 0;
                    //Parcourir tout le tableau de Formes
                    for (int i = 0; i < t_dataPoints.length; i++) {
                        for(int j = 0; j < t_dataPoints[0].length; j++) {

                            //Si la forme actuelle est dans le même cluster que le centroid actuel
                            if (t_dataPoints[i][j].getCluster() == z) {
                                //TotalE34[j] +=Forme[i][j].E34[j]
                                for(int it=0; it< totalSA.size(); it++){
                                    totalSA.set(it, totalSA.get(it) + t_dataPoints[i][j].SA.get(it));
                                    count++; }}
                        } }
                    if(count>0){
                        for(int i=0;i<totalSA.size();i++) {
                            //Assigner la moyenne des valeurs dans la meme position ( Somme(total[i])/ nombre_total)
                            totalSA.set(i, totalSA.get(i)/count);}
                        newCentroids.add(new Forme(null, null,totalSA,null)); }
                }
                //Le centroid reçois les nouveaux centres
                this.centroids = newCentroids;
                totalSA.clear();

                break;

            case "F0":
                //Listes pour calculer la moyenne de chaque caracteristique
                ArrayList<Double>  totalF0 = new ArrayList<>();

                //initialiser la Liste avec des zeros
                for(int i = 0; i< t_dataPoints[0][0].F0.size(); i++){ totalF0.add(0.0);}

                //Parcourir tous les elements des centroids
                for (int z = 0; z < k; z++) {

                    //Parcourir tous les elements de la caracteristique E34 (16 elements)
                    int count = 0;
                    //Parcourir tout le tableau de Formes
                    for (int i = 0; i < t_dataPoints.length; i++) {
                        for(int j = 0; j < t_dataPoints[0].length; j++) {

                            //Si la forme actuelle est dans le même cluster que le centroid actuel
                            if (t_dataPoints[i][j].getCluster() == z) {
                                //TotalE34[j] +=Forme[i][j].E34[j]
                                for(int it=0; it< totalF0.size(); it++){
                                    totalF0.set(it, totalF0.get(it) + t_dataPoints[i][j].F0.get(it));
                                    count++; }}
                        } }
                    if(count>0){
                        for(int i=0;i<totalF0.size();i++) {
                            //Assigner la moyenne des valeurs dans la meme position ( Somme(total[i])/ nombre_total)
                            totalF0.set(i, totalF0.get(i)/count);}
                        newCentroids.add(new Forme(null, null,null,totalF0)); }
                }
                //Le centroid reçois les nouveaux centres
                this.centroids = newCentroids;
                totalF0.clear();
                break;

        }
    }

    // Calculer la distance Euclideenne entre deux Formes selon la caracteristique choisis(E34, GFD, SA, F0)
    private double calculateDistance(ArrayList<Double> a, ArrayList<Double> b, int p) {
        double s=0.0;
        for(int i=0; i<b.size(); i++){
            s+= Math.pow(Math.abs(a.get(i)- b.get(i)), p);
        }
        return Math.pow(s, (double)(1.0/p) );
    }

    //K-means clustering
    public void cluster(String s, int p) {
         try{
            assigner_Clusters(s, p);
            ajuster_Centroids(s);
        }catch(Exception e){ System.out.print(e.getCause());}
        }
    }

/*
*
* BDShape[9][11] de Forme= [     [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]      ]

                        * Où chaque ligne represente une classe de formes
                        * Chaque colonne represente des echantillons
                        * BDShape [5][8] Represente l'echantillon 9 de la classe 6
        Forme {
              E34= <25, 2, 5, 6, 8, ....., 5>
              GFD= <25, 2, 5, 6, 8, ....., 5>
              SA= <25, 2, 5, 6, 8, ....., 5>
              F0= <25, 2, 5, 6, 8, ....., 5>
                };
* */









