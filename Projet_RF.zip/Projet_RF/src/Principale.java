import java.util.Random;
import java.util.Scanner;

public class Principale {
    public static void main(String[] args) {

        Criteres c1 = new Criteres();
        Forme[][] t_dataPoints1 = c1.BdShape;
        Scanner sc = new Scanner(System.in);

        // Specify the number of clusters (k)
        int k = 9;

        //Par default p=2 pour la distance Euclidienne
        //int p;

        //Choisir une Norme au hasard pour la distance de Minkowski
        Random rand = new Random();
        int[] p_norme = {1, 2, (3 + rand.nextInt(10))};

        for (int p=1; p<4; p++) {

            //Tableau pour chaque Temps d'execution de Caracteristique
            double[] t_ex_e34 = new double[10];
            double[] t_ex_gfd = new double[10];
            double[] t_ex_sa = new double[10];
            double[] t_ex_f0 = new double[10];

            //Tableau pour Precision generale de chaque Caracteristique
            double[] p_ex_e34 = new double[10];
            double[] p_ex_gfd = new double[10];
            double[] p_ex_sa = new double[10];
            double[] p_ex_f0 = new double[10];

            //Tableau pour Rappel general de chaque Caracteristique
            double[] r_ex_e34 = new double[10];
            double[] r_ex_gfd = new double[10];
            double[] r_ex_sa = new double[10];
            double[] r_ex_f0 = new double[10];

            //Tableau pour Vrais Positifs de chaque Caracteristique
            double[] po_ex_e34 = new double[10];
            double[] po_ex_gfd = new double[10];
            double[] po_ex_sa = new double[10];
            double[] po_ex_f0 = new double[10];



            String[] methode = {"E34", "GFD", "SA", "F0"};
            String[] distance = {"Manhatten", "Euclidienne", "Minkowski de norme_"+p_norme[2]};


            //Executer les 4 methodes
            for (int m = 0; m < 4; m++) {

                String s = methode[m];

                for (int it = 0; it < 10; it++) {

                    // Create KMeansClustering instance and perform clustering
                    KMeans kMeans = new KMeans(t_dataPoints1, k);
                    //kMeans.cluster("SA");


                    //Calculer le temps d'execution de chaque methode
                    // start time
                    long startTime = System.nanoTime();

                    // Call the method you want to measure the execution time of

                    kMeans.cluster(s, p);

                    // end time
                    long endTime = System.nanoTime();

                    // Calculate the execution time in milliseconds
                    long executionTime = (endTime - startTime) / 1000000;

                    // execution time
                    System.out.println("Le temps d'execution de la methode " + s + " est: " + executionTime + " millisecondes. || " + (endTime - startTime) + " nanosecondes");

                    switch (m) {
                        case 0:
                            t_ex_e34[it] = (double) (endTime - startTime) / 1000000;
                            break;
                        case 1:
                            t_ex_gfd[it] = (double) (endTime - startTime) / 1000000;
                            break;
                        case 2:
                            t_ex_sa[it] = (double) (endTime - startTime) / 1000000;
                            break;
                        case 3:
                            t_ex_f0[it] = (double) (endTime - startTime) / 1000000;
                            break;
                    }

                    //Affichage des nouveaux Clusters
                    for (int c = 0; c < k; c++) {
                        int nb_c = 0;
                        System.out.println("Cluster " + c + ":");

                        //Parcourir toutes les formes de BDShape et leur Cluster
                        for (int i = 0; i < t_dataPoints1.length; i++) {
                            for (int j = 0; j < t_dataPoints1[0].length; j++) {

                                //Afficher les formes d'un Cluster c
                                if (t_dataPoints1[i][j].getCluster() == c) {

                                    System.out.println("(" + t_dataPoints1[i][j].getE34() + "\n\n, " + t_dataPoints1[i][j].getGFD() + "\n\n, "
                                            + t_dataPoints1[i][j].getSA() + "\n, " + t_dataPoints1[i][j].getF0() + ")");
                                    nb_c++;
                                }
                            }
                        }
                        System.out.println(); // Empty line for separation
                        System.out.println("Cluster " + c + " Contient " + nb_c + " Elements.");
                        System.out.println("_____________________________________________________________________________________________________________________");
                    }

                    System.out.println(kMeans.centroids);


                    //Precision
                    Double[] prec = new Double[9];

                    //Rappel
                    Double[] rapp = new Double[9];

                    //Afficher matrice de confusion
                    Double[][] mat = c1.Mat_confus(t_dataPoints1);
                    int vp = 0;
                    int vn = 0;
                    int nb = 0;
                    double nb_c;
                    double pt = 0, rt = 0;

                    System.out.println("Matrice de confusion: ");
                    for (int i = 0; i < 9; i++) {
                        for (int j = 0; j < 9; j++) {
                            //Affichage ligne par ligne
                            System.out.print("   " + mat[i][j]);

                            //Les Vrais Negatifs
                            if (j != i) vn += mat[i][j];

                            //Nb elements d'une Colonne
                            nb += mat[j][i];


                        }
                        //Nb elements corrects
                        nb_c = mat[i][i];

                        //Precision (Nb_Correct/Nb_total)
                        prec[i] = nb_c / nb;

                        //Rappel
                        rapp[i] = nb_c / 11;

                        nb = 0;

                        //Les vrais Positifs
                        vp += mat[i][i];
                        System.out.println();
                    }
                    System.out.println("\n Vrais Positifs: " + vp + "\n Vrais Negatifs: " + vn);

                    for (int i = 0; i < 9; i++) {
                        System.out.print("\n\n Precision de la classe " + i + " est: ");
                        System.out.printf("%.3f", prec[i]);

                        System.out.print("\n Rappel de la classe " + i + " est: ");
                        System.out.printf("%.3f", rapp[i]);
                        pt += prec[i];
                        rt += rapp[i];
                    }
                    System.out.printf("\n\n %s%.3f", "Precison Totale: ", (pt / 9));
                    System.out.printf("\n %s%.3f", "Rappel Total: ", (rt / 9));

                    //Collecter les données de precision pour chaque methode
                    switch (m) {
                        case 0:
                            p_ex_e34[it] = (double) (pt / 9) * 100;
                            r_ex_e34[it] = (double) (rt / 9) * 100;
                            po_ex_e34[it] = vp;

                            break;
                        case 1:
                            p_ex_gfd[it] = (double) (pt / 9) * 100;
                            r_ex_gfd[it] = (double) (rt / 9) * 100;
                            po_ex_gfd[it] = vp;

                            break;
                        case 2:
                            p_ex_sa[it] = (double) (pt / 9) * 100;
                            r_ex_sa[it] = (double) (rt / 9) * 100;
                            po_ex_sa[it] = vp;

                            break;
                        case 3:
                            p_ex_f0[it] = (double) (pt / 9) * 100;
                            r_ex_f0[it] = (double) (rt / 9) * 100;
                            po_ex_f0[it] = vp;

                            break;
                    }

                }
            }

            System.out.println("\n Temps E34:");
            for (int n = 0; n < 10; n++)
                System.out.println(t_ex_e34[n]);

            System.out.println("\n Temps GFD");
            for (int n = 0; n < 10; n++)
                System.out.println(t_ex_gfd[n]);

            System.out.println("\n Temps SA");
            for (int n = 0; n < 10; n++)
                System.out.println(t_ex_sa[n]);

            System.out.println("\n temps F0");
            for (int n = 0; n < 10; n++)
                System.out.println(t_ex_f0[n]);

            //Affichage des graphiques
            Hist.Histo_car(distance[p-1], "Temps_Execution (ms)", t_ex_e34, t_ex_gfd, t_ex_sa, t_ex_f0);
            Hist.Histo_prec(distance[p-1],"Precision (%)", p_ex_e34, p_ex_gfd, p_ex_sa, p_ex_f0);
            Hist.Histo_rapp(distance[p-1],"Rappel (%)", r_ex_e34, r_ex_gfd, r_ex_sa, r_ex_f0);
            Hist.courb_pos(distance[p-1],"Vrais Positifs", po_ex_e34, po_ex_gfd, po_ex_sa, po_ex_f0);

        }
    }

}
