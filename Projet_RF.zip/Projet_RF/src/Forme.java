import java.util.ArrayList;

/*
*
* BDShape[9][11] de Forme= [     [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]
                                 [f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11]      ]

                        * Où chaque ligne represente une classe de formes
                        * Chaque colonne represente des echantillons
                        * BDShape [5][8] Represente l'echantillon 9 de la classe 6
        Forme {
              E34= <25, 2, 5, 6, 8, ....., 5>
              GFD= <25, 2, 5, 6, 8, ....., 5>
              SA= <25, 2, 5, 6, 8, ....., 5>
              F0= <25, 2, 5, 6, 8, ....., 5>
                };
* */

public class Forme {

        public ArrayList<Double> E34;
        public ArrayList<Double> GFD;
        public ArrayList<Double> SA;
        public ArrayList<Double> F0;
        private int Cluster;


        public Forme() {
            this.E34 =null;
            this.GFD =null;
            this.SA = null;
            this.F0 = null;
        }

        public Forme(ArrayList<Double> E34, ArrayList<Double> GFD, ArrayList<Double> SA, ArrayList<Double> F0) {
            this.E34 = E34;
            this.GFD = GFD;
            this.SA = SA;
            this.F0 = F0;
        }

        public ArrayList<Double> getE34() {
            return E34;
        }
        public void setE34(ArrayList<Double> E34) {
            this.E34 = E34;
        }

        public ArrayList<Double> getSA() {
            return SA;
        }
        public void setSA(ArrayList<Double> SA) {
            this.SA = SA;
        }

        public ArrayList<Double> getGFD() {
            return GFD;
        }
        public void setGFD(ArrayList<Double> GFD) {
            this.GFD = GFD;
        }

        public ArrayList<Double> getF0() {
            return F0;
        }
        public void setScore(ArrayList<Double> F0) {
            this.F0 = F0;
        }

        public void setCluster(int x){
            this.Cluster=x;
        }

        public int getCluster(){
            return this.Cluster;
        }

        /*
        @Override

        public String toString() {
            return "Record [id=" + id + ", age=" + age + ", income=" + income + ", score=" + score + ", clusterNumber="
                    + clusterNumber + "]";
        }

        */


    }


